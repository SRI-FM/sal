#!/bin/sh

#
# This script is used to install SAL in the binary distribution
#

echo "Installing SAL (version 2.4). Copyright (c) SRI International 2003, 2004."
echo "-------------------------------------------------------------------------"

salenv_dir=`pwd`
echo "Installation summary:"
echo "  SAL directory: $salenv_dir"
warning=0
wish_location=""

check_wish()
{
  if which tcl >2 /dev/null > /dev/null;
  then
     echo "TCL found"
		 if which wish 2> /dev/null > /dev/null; 
		 then	
				 wish_location=`which wish`
     else
         echo "WARNING: TCL/TK not found in your system."
     fi
  else
     echo "WARNING: TCL/TK not found in your system."
  fi
}

gen_script ()
{
  template=src/$1.template
  script=$salenv_dir/bin/$1
  if sed -e "s|__SALENV_DIR__|$salenv_dir|g;s|__SALENV_LIB_DIR__|$salenv_dir/lib|g;s|__BIGLOO_LIB_DIR__|$salenv_dir/lib/bigloo|g;s|__WISH__|$wish_location|g" $template > $script
  then
		chmod +x $script
	else
     echo "Error: generating script $script" 1>&2
		 exit 1
  fi
}

echo "Generating auxiliary scripts..."
for name in salenv salenv-safe sal-wfc lsal2xml sal2bool sal-smc sal-bmc sal-inf-bmc sal-path-finder sal-deadlock-checker sal-sim sal-wmc ltl2buchi sal-esmc sal-path-explorer; do gen_script $name; done

echo "Installation completed!"
echo "It is also a good idea to add the directory $salenv_dir/bin to your command search PATH environment variable."

