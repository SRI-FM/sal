#!/bin/sh

#
# This script is used to install SAL in the binary distribution
#

echo "Installing SAL (version 2.3). Copyright (c) SRI International 2003, 2004."
echo "-------------------------------------------------------------------------"

salenv_dir=`pwd`
echo "Installation summary:"
echo "  SAL directory: $salenv_dir"
warning=0

gen_script ()
{
  template=src/$1.template
  script=$salenv_dir/bin/$1
  if sed -e "s|__SALENV_DIR__|$salenv_dir|g;s|__SALENV_LIB_DIR__|$salenv_dir/lib|g" $template > $script
  then
		chmod +x $script
	else
     echo "Error: generating script $script" 1>&2
		 exit 1
  fi
}

echo "Generating auxiliary scripts..."
for name in salenv salenv-safe sal-wfc lsal2xml sal2bool sal-smc sal-bmc sal-inf-bmc sal-path-finder sal-deadlock-checker sal-sim sal-wmc ltl2buchi; do gen_script $name; done

echo "Installation completed!"
echo "It is also a good idea to add the directory $salenv_dir/bin to your command search PATH environment variable."

