/*
 * SAL 
 * Copyright (C) 2006, SRI International.  All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details. 
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software 
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. 
 *
 */

#include<time.h>

#include "bigloo.h"

typedef struct clock_list * clock_list_ptr;

struct clock_list {
  clock_t runtime_start;
  clock_list_ptr next;
};

clock_list_ptr ClockList = NULL;

#ifdef HAS_SYS_TIMES
#include<sys/times.h>

struct tms TimeInfo;

void initialize_runtime()
{
  clock_list_ptr new_node = (clock_list_ptr) GC_malloc(sizeof(struct clock_list));
  times(&TimeInfo);
  new_node->runtime_start = TimeInfo.tms_utime + TimeInfo.tms_stime + TimeInfo.tms_cutime + TimeInfo.tms_cstime; /* collects children processes time */
  new_node->next = ClockList;
  ClockList = new_node;
}

double collect_elapsed()
{
  clock_t end; 
  double result;
  times(&TimeInfo);
  end = TimeInfo.tms_utime + TimeInfo.tms_stime + TimeInfo.tms_cutime + TimeInfo.tms_cstime; 
#ifdef OS_darwin
  result = ((double) (end - ClockList->runtime_start)) / CLOCKS_PER_SEC;
#else
  result = ((double) (end - ClockList->runtime_start)) / CLK_TCK; /* Doesn't work -> / CLOCKS_PER_SEC; */
#endif
  return result;
}

double collect_runtime()
{
  double result = collect_elapsed();
  ClockList = ClockList->next;
  return result;
}

#else

/* sys/times.h is not available... using less precise functions... */

void initialize_runtime()
{
  clock_list_ptr new_node = (clock_list_ptr) GC_malloc(sizeof(struct clock_list));
  new_node->runtime_start = clock();
  new_node->next = ClockList;
  ClockList = new_node;
}

double collect_elapsed()
{
  clock_t end; 
  double result;
  end = clock();
  result = ((double) (end - ClockList->runtime_start)) / CLOCKS_PER_SEC;
  return result;
}

double collect_runtime()
{
  double result = collect_elapsed();
  ClockList = ClockList->next;
  return result;
}

#endif

