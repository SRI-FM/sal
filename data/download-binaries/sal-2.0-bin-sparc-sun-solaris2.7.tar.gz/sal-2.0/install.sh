#!/bin/sh

#
# This script is used to install SAL in the binary distribution
#

echo "Installing SAL (version 2.0). Copyring (c) SRI International 2003."
echo "------------------------------------------------------------------"

check_java_version() {
java -version > /dev/null 2> /dev/null
if [ $? -eq 0 ]; then
		ver=`java -version 2>&1 | sed -e '2,$d' | sed -e 's/[^0-9\.]//g' | sed -e 's/[\.][\.]*/\./g' | sed -e 's/^\.//g' | sed -e 's/\.$//g'`
		major=`echo $ver | awk -F . '{print $1}'`
		minor=`echo $ver | awk -F . '{print $2}'`
		if [ $major -lt 1 ]; then
				return 1
		fi
		if [ $major -eq 1 ] && [ $minor -lt 4 ]; then
				return 1
		fi
		return 0
else
		return 1
fi
}

check_java_version
if [ $? -ne 0 ]; then
		echo "Could not find Java version >= 1.4.0 on your computer." 1>&2
		exit 1
fi

salenv_dir=`pwd`
echo "Installation summary:"
echo "  SAL directory: $salenv_dir"
warning=0

gen_script ()
{
  template=src/$1.template
  script=$salenv_dir/bin/$1
  if sed -e "s|__SALENV_DIR__|$salenv_dir|g;s|__SALENV_LIB_DIR__|$salenv_dir/lib|g" $template > $script
  then
		chmod +x $script
	else
     echo "Error: generating script $script" 1>&2
		 exit 1
  fi
}

echo "Generating auxiliary scripts..."
for name in salenv salenv-safe sal-wfc lsal2xml sal2bool sal-smc sal-bmc sal-inf-bmc sal-path-finder sal-deadlock-checker sal-sim; do gen_script $name; done
gen_script sal2xml2

echo "Installation completed!"
echo "It is also a good idea to add the directory $salenv_dir/bin to your command search PATH environment variable."

