/* Automatically generated file (don't edit) */
/* Mon Nov  1 13:22:38 PST 2004 */

#ifndef BIGLOO_CONFIG_H
#define BIGLOO_CONFIG_H

#undef BGL_RELEASE_NUMBER
#define BGL_RELEASE_NUMBER "2.6e"

#undef BGL_SPECIFIC_VERSION
#define BGL_SPECIFIC_VERSION ""

#undef BGL_DEFAULT_BACK_END
#define BGL_DEFAULT_BACK_END "native"

#undef BGL_DEFAULT_A_OUT
#define BGL_DEFAULT_A_OUT "a.out"

#undef BGL_DEFAULT_A_BAT
#define BGL_DEFAULT_A_BAT "a.out"

#undef STACK_GROWS_DOWN
#define STACK_GROWS_DOWN 1

#undef PTR_ALIGNMENT
#define PTR_ALIGNMENT 2

#undef SETJMP
#define SETJMP setjmp
#undef LONGJMP
#define LONGJMP longjmp

#undef HAVE_BCOPY
#define HAVE_BCOPY 1

#undef NB_WINDOW_REGISTER
#define NB_WINDOW_REGISTER 0

#undef HAVE_SIGSETMASK
#define HAVE_SIGSETMASK 1

#undef HAVE_SIGPROCMASK
#define HAVE_SIGPROCMASK 1

#undef HAVE_ALLOCA
#define HAVE_ALLOCA 1

#undef HAVE_GETCWD
#define HAVE_GETCWD 1

#undef HAVE_GETWD
#define HAVE_GETWD 1

#undef CONSTANT_ALIGNED
#define CONSTANT_ALIGNED 1

#undef BGL_BIG_ENDIAN
#define BGL_BIG_ENDIAN 1

#undef HAVE_PIPE
#define HAVE_PIPE 1

#undef BGL_LONGLONG_T
#define BGL_LONGLONG_T long long
#define BGL_HAVE_LLABS 1
#define BGL_LLABS llabs
#define BGL_HAVE_STRTOLL 1
#define BGL_STRTOLL strtoll

#undef HAVE_SIGCHLD
#define HAVE_SIGCHLD 1

#undef HAVE_SIGACTION
#define HAVE_SIGACTION 1

#undef BGL_HAVE_SELECT
#define BGL_HAVE_SELECT 1

#undef HAVE_TERMIO
#define HAVE_TERMIO 0

#undef POSIX_FILE_OPS
#define POSIX_FILE_OPS 1

#undef BGL_HAVE_SENDFILE
#define BGL_HAVE_SENDFILE 0

#undef BGL_NANOSLEEP
#define BGL_NANOSLEEP 1

#undef BGL_SLEEP
#define BGL_SLEEP 1

#undef BGL_TIMEZONE
#define BGL_TIMEZONE 0

#undef HAVE_SHARED_LIBRARY
#define HAVE_SHARED_LIBRARY 1
#define HAVE_DLOPEN 1
#define DLOPEN_LD_OPT "-ldl"
#define OS_CLASS "unix"
#define OS_NAME "Darwin"
#define OS_ARCH "Power Macintosh"
#define OS_VERSION "7.5.1"
#define OS_TMP "/tmp"
#define FILE_SEPARATOR '/'
#define PATH_SEPARATOR ':'
#define STATIC_LIB_SUFFIX "a"
#define SHARED_LIB_SUFFIX "so"
#define UCS2_DISPLAYABLE 0

#undef SHELL
#define SHELL "/bin/sh"

#undef C_COMPILER_STYLE
#define C_COMPILER_STYLE "gcc"

#undef C_COMPILER
#define C_COMPILER "gcc"

#undef C_FLAGS
#define C_FLAGS ""

#undef C_COMPILER_O_OPTION
#define C_COMPILER_O_OPTION "-o "

#undef C_COMPILER_DEBUG_OPTION
#define C_COMPILER_DEBUG_OPTION "-g"

#undef C_OBJECT_FILE_EXTENSION
#define C_OBJECT_FILE_EXTENSION "o"

#undef C_COMPILER_OPTIM_FLAGS
#define C_COMPILER_OPTIM_FLAGS "-O3 "

#undef C_STRIP_FLAGS
#define C_STRIP_FLAGS "-s"

#undef C_LINKER_STYLE
#define C_LINKER_STYLE "gcc"

#undef C_LINKER_O_OPTION
#define C_LINKER_O_OPTION "-o "

#undef C_LINKER_DEBUG_OPTION
#define C_LINKER_DEBUG_OPTION "-g "

#undef C_LINKER_OPTIM_FLAGS
#define C_LINKER_OPTIM_FLAGS ""

#undef C_PROFILE_FLAGS
#define C_PROFILE_FLAGS "-pg -fno-inline "

#undef C_STRING_SPLIT
#define C_STRING_SPLIT 0

#undef BGL_LD_LIBRARY_DIR
#define BGL_LD_LIBRARY_DIR "/usr/local/lib"

#undef LIBRARY_DIRECTORY
#define LIBRARY_DIRECTORY "/usr/local/lib/bigloo/2.6e"

#undef BGL_GC_LIBRARY
#define BGL_GC_LIBRARY "bigloogc"

#undef BGL_GC_CUSTOM
#define BGL_GC_CUSTOM 1

#undef ZIP_DIRECTORY
#define ZIP_DIRECTORY "/usr/local/lib/bigloo/2.6e"

#undef DLL_DIRECTORY
#define DLL_DIRECTORY "/usr/local/lib/bigloo/2.6e"

#undef USER_LIBRARIES
#define USER_LIBRARIES "-ldl -lm"

#undef C_BEAUTIFIER
#define C_BEAUTIFIER ""

#undef DIRNAME_CMD
#define DIRNAME_CMD "dirname"

#undef LIBRARY_BASE_NAME
#define LIBRARY_BASE_NAME "bigloo"

#undef DOUBLE_PRECISION
#define DOUBLE_PRECISION 14

#undef ADDITIONAL_STATIC_LINK_OPTION
#define ADDITIONAL_STATIC_LINK_OPTION ""

#undef ADDITIONAL_SHARED_LINK_OPTION
#define ADDITIONAL_SHARED_LINK_OPTION ""

#undef BGL_HAVE_BIGLOO_ABORT
#define BGL_HAVE_BIGLOO_ABORT 0

#undef BGL_HEAP_DEBUG_COPT
#define BGL_HEAP_DEBUG_COPT "-DKEEP_BACK_PTRS"

#undef BGL_HAVE_BDB
#define BGL_HAVE_BDB 0

#undef BGL_JAVA
#define BGL_JAVA "java"
#undef BGL_JAVA_OPT
#define BGL_JAVA_OPT ""
#undef BGL_JAVA_VOPT
#define BGL_JAVA_VOPT ""
#undef BGL_JAR
#define BGL_JAR ""
#undef BGL_JAVA_SHELL
#define BGL_JAVA_SHELL "sh"

#undef BGL_DOTNET_LD
#define BGL_DOTNET_LD ""
#undef BGL_DOTNET_LD_STYLE
#define BGL_DOTNET_LD_STYLE ""
#undef BGL_DOTNET_CLR
#define BGL_DOTNET_CLR ""
#undef BGL_DOTNET_CLR_STYLE
#define BGL_DOTNET_CLR_STYLE ""
#undef BGL_DOTNET_CLR_OPT
#define BGL_DOTNET_CLR_OPT ""
#undef BGL_DOTNET_SHELL
#define BGL_DOTNET_SHELL ""
#undef BGL_DOTNET_ASM
#define BGL_DOTNET_ASM ""

#undef BGL_IMPORT
#define BGL_IMPORT extern

#undef BGL_EXPORTED_DECL
#define BGL_EXPORTED_DECL extern

#undef BGL_EXPORTED_DEF
#define BGL_EXPORTED_DEF

#undef BGL_RUNTIME_DECL
#define BGL_RUNTIME_DECL extern

#undef BGL_RUNTIME_DEF
#define BGL_RUNTIME_DEF

#endif
